import prompt


def get_user_name():
    return prompt.string("May I have your name? ")
